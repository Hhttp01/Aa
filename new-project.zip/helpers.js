export const generateId = () => `id-${Math.random().toString(36).substr(2, 9)}`;

export const cleanNameString = (str) => {
  return str
    .replace(/[│┃┆┇┊┋├┝┞┟┠┡┢┣┤┥┦┧┨┩┪┫┬┭┮┯┰┱┲┳┴┵┶┷┸┹┺┻┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋═║╒╓╔╕╖╗╘╙╚╛╜╝╞╟╠╡╢╣╤╥╦╧╨╩╪╫╬⌞⌟⌜⌝└┕┖┗┘┙┚┛─━]/g, '')
    .replace(/[📂📁📄📝➖➕🌿]/g, '')
    .trim();
};