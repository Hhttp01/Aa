import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { auth, db, appId } from './firebase/config';
import { onAuthStateChanged, signInAnonymously } from 'firebase/auth';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';

// ייבוא קומפוננטות
import TreeItem from './components/Sidebar/TreeItem';
import CodeEditor from './components/Editor/CodeEditor';

// ייבוא פונקציות עזר
import { findNodeById, generateId, cleanNameString } from './utils/treeUtils';
import { loadJSZip, addNodeToZip, triggerDownload } from './utils/zipUtils';

// ייבוא אייקונים ולוגיקה ויזואלית
import { Code2, Download, Search, RefreshCcw, Layers, PlusSquare } from 'lucide-react';

const EMPTY_PROJECT_STRUCTURE = { id: 'root', name: 'new-project', type: 'folder', children: [] };

const App = () => {
  const [user, setUser] = useState(null);
  const [tree, setTree] = useState(EMPTY_PROJECT_STRUCTURE);
  const [editingFileId, setEditingFileId] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedFolders, setExpandedFolders] = useState(new Set(['root']));
  const [quickPath, setQuickPath] = useState("");
  const [bulkPathInput, setBulkPathInput] = useState("");

  // --- Auth & Sync ---
  useEffect(() => {
    signInAnonymously(auth);
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    const docRef = doc(db, 'artifacts', appId, 'users', user.uid, 'projects', 'main-tree');
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) setTree(docSnap.data());
    });
    return () => unsubscribe();
  }, [user]);

  const saveToCloud = async (currentTree) => {
    if (!user) return;
    setIsSaving(true);
    try {
      const docRef = doc(db, 'artifacts', appId, 'users', user.uid, 'projects', 'main-tree');
      await setDoc(docRef, JSON.parse(JSON.stringify(currentTree)));
    } finally {
      setTimeout(() => setIsSaving(false), 800);
    }
  };

  // --- Handlers ---
  const handleUpdateContent = (newContent) => {
    if (!editingFileId) return;
    const newTree = JSON.parse(JSON.stringify(tree));
    const file = findNodeById(newTree, editingFileId);
    if (file) {
      file.content = newContent;
      setTree(newTree);
      saveToCloud(newTree);
    }
  };

  const handleExportZip = async () => {
    const JSZip = await loadJSZip();
    const zip = new JSZip();
    tree.children.forEach(child => addNodeToZip(child, zip));
    const content = await zip.generateAsync({ type: "blob" });
    triggerDownload(content, `${tree.name}.zip`);
  };

  const activeFile = useMemo(() => 
    editingFileId ? findNodeById(tree, editingFileId) : null
  , [editingFileId, tree]);

  return (
    <div className="h-screen w-full flex flex-col bg-slate-950 text-slate-200 overflow-hidden" dir="rtl">
      {/* Header */}
      <header className="h-14 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/40 backdrop-blur-xl shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Code2 size={20} className="text-white" />
          </div>
          <h1 className="text-sm font-bold tracking-tight">Path Forge <span className="text-blue-500">OS Pro</span></h1>
        </div>
        <button onClick={handleExportZip} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-1.5 rounded-lg text-xs font-bold transition-all">
          <Download size={14} /> הורד פרויקט (ZIP)
        </button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-80 border-l border-slate-800 bg-slate-900/20 flex flex-col shrink-0">
          <div className="p-4 border-b border-slate-800/50 space-y-4">
            <div className="relative">
              <Search className="absolute right-3 top-2.5 text-slate-600" size={14} />
              <input 
                className="w-full bg-slate-950/50 border border-slate-800 rounded-lg pr-9 pl-3 py-2 text-xs outline-none focus:border-blue-500" 
                placeholder="חיפוש קבצים..." 
                value={searchTerm} 
                onChange={e => setSearchTerm(e.target.value)} 
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto px-2 py-4">
            {tree.children.map(child => (
              <TreeItem 
                key={child.id}
                node={child}
                depth={0}
                expandedFolders={expandedFolders}
                toggleExpand={(id) => {
                  const next = new Set(expandedFolders);
                  next.has(id) ? next.delete(id) : next.add(id);
                  setExpandedFolders(next);
                }}
                onSelect={setEditingFileId}
                editingFileId={editingFileId}
                // כאן תוסיף את שאר הפרופס (onDelete, onRename וכו')
              />
            ))}
          </div>
        </aside>

        {/* Editor */}
        <main className="flex-1 bg-slate-950 relative">
          {activeFile ? (
            <CodeEditor 
              activeFile={activeFile}
              onContentChange={handleUpdateContent}
              onClose={() => setEditingFileId(null)}
              isSaving={isSaving}
              getFileIcon={() => <Code2 size={16}/>} // פונקציה מה-Utils
            />
          ) : (
            <div className="h-full flex flex-col items-center justify-center opacity-20">
              <Code2 size={80} />
              <p className="mt-4 text-sm font-bold">בחר קובץ לעריכה</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;