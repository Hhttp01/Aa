/**
 * טוען את ספריית JSZip מרחוק אם היא לא קיימת
 */
export const loadJSZip = () => {
  return new Promise((resolve, reject) => {
    if (window.JSZip) return resolve(window.JSZip);
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
    script.onload = () => resolve(window.JSZip);
    script.onerror = reject;
    document.head.appendChild(script);
  });
};

/**
 * פונקציה רקורסיבית שמוסיפה קבצים ותיקיות לאובייקט ה-ZIP
 */
export const addNodeToZip = (node, currentZipFolder) => {
  if (node.type === 'file') {
    currentZipFolder.file(node.name, node.content || "");
  } else {
    const newFolder = currentZipFolder.folder(node.name);
    if (node.children) {
      node.children.forEach(child => addNodeToZip(child, newFolder));
    }
  }
};

/**
 * יצירת הורדה של ה-Blob בדפדפן
 */
export const triggerDownload = (blob, fileName) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};