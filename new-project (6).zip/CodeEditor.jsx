import React from 'react';
import { X, Save, FileCode } from 'lucide-react';

const CodeEditor = ({ activeFile, onContentChange, onClose, isSaving, getFileIcon }) => {
  return (
    <div className="h-full flex flex-col">
      {/* Tab Header */}
      <div className="h-11 border-b border-slate-800 flex items-center justify-between bg-slate-900/30 px-4">
        <div className="flex items-center gap-2 text-xs text-blue-400 font-mono bg-slate-800/50 border border-slate-700/50 rounded-t-lg px-4 py-2 mt-1 translate-y-[1px]">
          {getFileIcon(activeFile.name)}
          <span className="font-bold tracking-tight">{activeFile.name}</span>
          <button onClick={onClose} className="mr-2 hover:text-white p-0.5 rounded hover:bg-slate-700 transition-colors">
            <X size={12} />
          </button>
        </div>
        
        {isSaving && (
          <div className="flex items-center gap-1 text-[10px] text-amber-500 font-bold animate-pulse">
            <Save size={12} />
            סנכרון לענן...
          </div>
        )}
      </div>

      {/* Text Area */}
      <textarea 
        className="flex-1 bg-transparent p-6 outline-none font-mono text-sm leading-relaxed text-slate-300 resize-none scrollbar-thin scrollbar-thumb-slate-800 placeholder:text-slate-800" 
        value={activeFile.content || ""} 
        onChange={(e) => onContentChange(e.target.value)} 
        spellCheck="false" 
        autoFocus 
        placeholder="// התחל לכתוב קוד..."
      />
    </div>
  );
};

export default CodeEditor;