export const generateId = () => `id-${Math.random().toString(36).substr(2, 9)}`;

export const cleanNameString = (str) => {
  return str
    .replace(/[│┃┆┇┊┋├┝┞┟┠┡┢┣┤┥┦┧┨┩┪┫┬┭┮┯┰┱┲┳┴┵┶┷┸┹┺┻┼┽┾┿╀╁╂╂╃╄╅╆╇╈╉╊╋═║╒╓╔╕╖╗╘╙╚╛╜╝╞╟╠╡╢╣╤╥╦╧╨╩╪╫╬⌞⌟⌜⌝└┕┖┗┘┙┚┛├┝┞┟┠┡┢┣┬┭┮┯┰┱┲┳─━]*/g, '')
    .replace(/📂|📁|📄|📝|➖|➕|🌿/g, '')
    .split('#')[0]
    .split('//')[0]
    .trim();
};

export const findNodeById = (node, id) => {
  if (node.id === id) return node;
  if (node.children) {
    for (const child of node.children) {
      const found = findNodeById(child, id);
      if (found) return found;
    }
  }
  return null;
};