import React from 'react';
import { Folder, FileText, ChevronRight, ChevronDown, Trash2, Download, FilePlus, FolderPlus, Globe, FileJson, FileCode, Hash } from 'lucide-react';

const getFileIcon = (name) => {
  const ext = name.split('.').pop().toLowerCase();
  switch(ext) {
    case 'html': return <Globe size={16} className="text-orange-400" />;
    case 'json': return <FileJson size={16} className="text-yellow-400" />;
    case 'css': return <Hash size={16} className="text-blue-400" />;
    case 'js': case 'jsx': case 'ts': case 'tsx': return <FileCode size={16} className="text-blue-300" />;
    default: return <FileText size={16} className="text-slate-400" />;
  }
};

const TreeItem = ({ node, depth, expandedFolders, toggleExpand, onSelect, onRename, onDelete, onAdd, onDownload, editingFileId }) => {
  const isExpanded = expandedFolders.has(node.id);
  const isActive = editingFileId === node.id;

  return (
    <div className="select-none">
      <div 
        onClick={() => node.type === 'folder' ? toggleExpand(node.id) : onSelect(node.id)}
        className={`group flex items-center gap-2 py-1 px-3 cursor-pointer rounded-lg transition-all 
          ${isActive ? 'bg-blue-600/20 text-blue-400' : 'hover:bg-slate-800/50 text-slate-400 hover:text-slate-100'}`}
        style={{ paddingRight: `${depth * 14}px` }}
      >
        <span className="shrink-0 opacity-50">
          {node.type === 'folder' ? (isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />) : <div className="w-3.5" />}
        </span>
        <span className="shrink-0">
          {node.type === 'folder' ? <Folder size={15} className={isExpanded ? 'text-blue-400' : 'text-slate-500'} /> : getFileIcon(node.name)}
        </span>
        <input 
          className="text-sm truncate flex-1 bg-transparent border-none outline-none focus:bg-slate-800/80 rounded px-1 transition-all"
          value={node.name}
          onChange={(e) => onRename(node.id, e.target.value)}
          onClick={(e) => e.stopPropagation()}
        />
        
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-all mr-auto">
          {node.type === 'folder' && (
            <>
              <button onClick={(e) => { e.stopPropagation(); onAdd(node.id, 'file'); }} className="p-1 hover:bg-green-500/20 text-green-500 rounded"><FilePlus size={12} /></button>
              <button onClick={(e) => { e.stopPropagation(); onAdd(node.id, 'folder'); }} className="p-1 hover:bg-blue-500/20 text-blue-400 rounded"><FolderPlus size={12} /></button>
            </>
          )}
          <button onClick={(e) => { e.stopPropagation(); onDownload(node); }} className="p-1 hover:bg-blue-500/20 text-blue-400 rounded"><Download size={12} /></button>
          <button onClick={(e) => onDelete(node.id, e)} className="p-1 hover:bg-red-500/20 text-red-400 rounded"><Trash2 size={12} /></button>
        </div>
      </div>
      {isExpanded && node.children && (
        <div className="border-r border-slate-800/50 mr-4">
          {node.children.map(child => (
            <TreeItem key={child.id} node={child} depth={depth + 1} expandedFolders={expandedFolders} toggleExpand={toggleExpand} onSelect={onSelect} onRename={onRename} onDelete={onDelete} onAdd={onAdd} onDownload={onDownload} editingFileId={editingFileId} />
          ))}
        </div>
      )}
    </div>
  );
};

export default TreeItem;